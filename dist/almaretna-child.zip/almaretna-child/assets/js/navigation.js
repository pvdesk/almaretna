/* Almaretna — Navigation: hamburger, scroll header, booking-bar date logic */
(function () {
    'use strict';

    var header    = document.getElementById('site-header');
    var toggle    = document.getElementById('nav-toggle');
    var mobileNav = document.getElementById('mobile-nav');
    var closeBtn  = document.getElementById('nav-close');
    var backdrop  = document.getElementById('nav-backdrop');

    // ── Scroll: header background ─────────────────────────────────
    if (header) {
        var scrolled = false;
        window.addEventListener('scroll', function () {
            var shouldScroll = window.scrollY > 60;
            if (shouldScroll !== scrolled) {
                scrolled = shouldScroll;
                header.classList.toggle('is-scrolled', scrolled);
            }
        }, { passive: true });
    }

    // ── Mobile nav open/close ─────────────────────────────────────
    function openNav() {
        if (!mobileNav) return;
        mobileNav.classList.add('is-open');
        mobileNav.setAttribute('aria-hidden', 'false');
        if (backdrop) backdrop.classList.add('is-visible');
        if (toggle)   toggle.setAttribute('aria-expanded', 'true');
        document.body.style.overflow = 'hidden';
    }

    function closeNav() {
        if (!mobileNav) return;
        mobileNav.classList.remove('is-open');
        mobileNav.setAttribute('aria-hidden', 'true');
        if (backdrop) backdrop.classList.remove('is-visible');
        if (toggle)   toggle.setAttribute('aria-expanded', 'false');
        document.body.style.overflow = '';
    }

    if (toggle)   toggle.addEventListener('click', openNav);
    if (closeBtn) closeBtn.addEventListener('click', closeNav);
    if (backdrop) backdrop.addEventListener('click', closeNav);

    document.addEventListener('keydown', function (e) {
        if (e.key === 'Escape') closeNav();
    });

    // ── Booking bar: auto-advance checkin → checkout ──────────────
    var checkinInput  = document.getElementById('hb-checkin');
    var checkoutInput = document.getElementById('hb-checkout');

    if (checkinInput && checkoutInput) {
        checkinInput.addEventListener('change', function () {
            var ci = this.value;
            if (!ci) return;
            // checkout min = checkin + 1 day
            var minDate = new Date(ci);
            minDate.setDate(minDate.getDate() + 1);
            var y = minDate.getFullYear();
            var m = String(minDate.getMonth() + 1).padStart(2, '0');
            var d = String(minDate.getDate()).padStart(2, '0');
            checkoutInput.min = y + '-' + m + '-' + d;

            if (checkoutInput.value && checkoutInput.value <= ci) {
                checkoutInput.value = '';
            }
            checkoutInput.focus();
        });
    }

}());
