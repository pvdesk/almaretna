<?php
/**
 * Almaretna Child — front-page.php
 * Home page template.
 * Updated to use dynamic link resolution and a light, elegant beige and white color scheme.
 *
 * @package AlmaretnaChild
 */

declare(strict_types=1);

get_header();

// Recupera le camere in evidenza
$rooms = get_posts([
    'post_type'      => 'almaretna_room',
    'posts_per_page' => 3,
    'post_status'    => 'publish',
    'orderby'        => 'menu_order',
    'order'          => 'ASC',
]);

// ─── Risoluzione Dinamica dei Link ────────────────────────────────────────
$prenota_pages = get_pages(['meta_key' => '_wp_page_template', 'meta_value' => 'templates/template-booking.php', 'number' => 1]);
$prenota_url = !empty($prenota_pages) ? get_permalink($prenota_pages[0]->ID) : (get_permalink(get_page_by_path('prenota')) ?: home_url('/prenota/'));

$camere_pages = get_pages(['meta_key' => '_wp_page_template', 'meta_value' => 'templates/template-rooms.php', 'number' => 1]);
$camere_url = !empty($camere_pages) ? get_permalink($camere_pages[0]->ID) : (get_permalink(get_page_by_path('camere'))  ?: home_url('/camere/'));

// ─── Customizer Settings ──────────────────────────────────────────────────
// 1. Hero
$hero_bg_custom = get_theme_mod('almaretna_hero_bg');
if ($hero_bg_custom) {
    $hero_bg = $hero_bg_custom;
} elseif (has_post_thumbnail()) {
    $hero_bg = get_the_post_thumbnail_url(null, 'full');
} elseif (!empty($rooms) && has_post_thumbnail($rooms[0]->ID)) {
    $hero_bg = get_the_post_thumbnail_url($rooms[0]->ID, 'full');
} else {
    $hero_bg = '';
}

$hero_eyebrow  = get_theme_mod('almaretna_hero_eyebrow', 'Nunziata di Mascali · Sicilia');
$hero_title    = get_theme_mod('almaretna_hero_title', "Un rifugio\nalle pendici dell'Etna");
$hero_subtitle = get_theme_mod('almaretna_hero_subtitle', "Villa con piscina panoramica, camere eleganti\ne colazioni artigianali tra gli agrumeti.");

// 2. Villa Section
$villa_img_custom = get_theme_mod('almaretna_villa_img');
if ($villa_img_custom) {
    $villa_img = $villa_img_custom;
} elseif (count($rooms) > 1 && has_post_thumbnail($rooms[1]->ID)) {
    $villa_img = get_the_post_thumbnail_url($rooms[1]->ID, 'large');
} elseif (!empty($rooms) && has_post_thumbnail($rooms[0]->ID)) {
    $villa_img = get_the_post_thumbnail_url($rooms[0]->ID, 'large');
} else {
    $villa_img = '';
}

$villa_eyebrow = get_theme_mod('almaretna_villa_eyebrow', 'La nostra storia');
$villa_title   = get_theme_mod('almaretna_villa_title', 'Un angolo di Sicilia autentica');
$villa_text_1  = get_theme_mod('almaretna_villa_text_1', "Almaretna è una villa di charme immersa negli agrumeti alle pendici dell'Etna, nel suggestivo borgo di Nunziata di Mascali. Qui il tempo rallenta, i profumi di zagara riempiono l'aria e la vista sul vulcano ti lascia senza parole.");
$villa_text_2  = get_theme_mod('almaretna_villa_text_2', "Ogni camera è curata nei dettagli per offrirti il massimo del comfort, mentre la nostra piscina panoramica diventa il punto di incontro perfetto tra cielo, Etna e mare.");
?>

<main id="main" class="home-page" style="background-color: var(--color-bg);">

    <!-- ══ HERO ══════════════════════════════════════════════════ -->
    <section class="hero d-flex flex-column align-items-center justify-content-center text-center position-relative overflow-hidden"
             style="min-height: 100vh; background-color: var(--color-bg); <?php if ($hero_bg) echo 'background-image: url(' . esc_url($hero_bg) . ');'; ?> background-size: cover; background-position: center; background-attachment: fixed;">
        <div class="hero__overlay position-absolute top-0 start-0 end-0 bottom-0" 
             style="background: linear-gradient(180deg, rgba(252, 250, 247, 0.45) 0%, rgba(252, 250, 247, 0.78) 100%); z-index: 1;"></div>
        
        <div class="hero__content position-relative px-3" style="z-index: 2; max-width: 800px; color: var(--color-text);">
            <p class="hero__eyebrow text-uppercase fw-semibold tracking-widest mb-3" style="color: var(--color-secondary); font-size: 0.85rem; letter-spacing: 0.25em;">
                <?php echo esc_html($hero_eyebrow); ?>
            </p>
            <h1 class="hero__title display-2 fw-bold mb-3 font-heading" style="line-height: 1.15; color: #4A4136; text-shadow: 0 1px 8px rgba(255,255,255,0.6);">
                <?php echo nl2br(esc_html($hero_title)); ?>
            </h1>
            <p class="hero__subtitle fs-5 fw-light mb-5 mx-auto" style="max-width: 600px; line-height: 1.6; color: var(--color-text-light);">
                <?php echo esc_html($hero_subtitle); ?>
            </p>
            <div class="hero__actions d-flex flex-wrap justify-content-center gap-3">
                <a href="<?php echo esc_url($prenota_url); ?>" class="btn btn-primary btn-lg px-4 py-3 border-0 rounded-3 shadow-sm" style="background-color: var(--color-primary); color: var(--color-white);">
                    <?php esc_html_e('Prenota ora', 'almaretna-child'); ?>
                </a>
                <a href="<?php echo esc_url($camere_url); ?>" class="btn btn-outline-primary btn-lg px-4 py-3 rounded-3" style="border: 2px solid var(--color-primary); color: var(--color-primary);">
                    <?php esc_html_e('Scopri le camere', 'almaretna-child'); ?>
                </a>
            </div>
        </div>
    </section>

    <!-- ══ BOOKING BAR ══════════════════════════════════════════ -->
    <section class="booking-bar position-relative py-4 bg-white shadow-sm" style="z-index: 10; margin-top: -30px; border-radius: 12px; max-width: 1000px; margin-inline: auto; border: 1px solid var(--color-border);">
        <div class="container-fluid px-4">
            <form class="booking-bar__form row g-3 align-items-center" method="get" action="<?php echo esc_url($prenota_url); ?>">
                <div class="col-md-3">
                    <div class="px-2">
                        <label for="hb-checkin" class="d-flex align-items-center gap-2 text-uppercase fw-bold text-muted mb-2" style="font-size: 0.7rem; letter-spacing: 0.05em;">
                            <svg width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>
                            Check-in
                        </label>
                        <input type="date" id="hb-checkin" name="checkin" class="form-control border-0 p-0 fw-medium bg-transparent"
                               min="<?php echo esc_attr(gmdate('Y-m-d')); ?>" style="font-size: 0.95rem; box-shadow: none; color: var(--color-text);" />
                    </div>
                </div>
                <div class="col-md-1 d-none d-md-block text-center text-muted opacity-50">
                    <div style="width: 1px; height: 40px; background: var(--color-border); margin: 0 auto;"></div>
                </div>
                <div class="col-md-3">
                    <div class="px-2">
                        <label for="hb-checkout" class="d-flex align-items-center gap-2 text-uppercase fw-bold text-muted mb-2" style="font-size: 0.7rem; letter-spacing: 0.05em;">
                            <svg width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>
                            Check-out
                        </label>
                        <input type="date" id="hb-checkout" name="checkout" class="form-control border-0 p-0 fw-medium bg-transparent"
                               min="<?php echo esc_attr(gmdate('Y-m-d', strtotime('+1 day'))); ?>" style="font-size: 0.95rem; box-shadow: none; color: var(--color-text);" />
                    </div>
                </div>
                <div class="col-md-1 d-none d-md-block text-center text-muted opacity-50">
                    <div style="width: 1px; height: 40px; background: var(--color-border); margin: 0 auto;"></div>
                </div>
                <div class="col-md-2">
                    <div class="px-2">
                        <label for="hb-adults" class="d-flex align-items-center gap-2 text-uppercase fw-bold text-muted mb-2" style="font-size: 0.7rem; letter-spacing: 0.05em;">
                            <svg width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 00-3-3.87"/><path d="M16 3.13a4 4 0 010 7.75"/></svg>
                            Ospiti
                        </label>
                        <select id="hb-adults" name="adults" class="form-select border-0 p-0 fw-medium bg-transparent" style="font-size: 0.95rem; box-shadow: none; cursor: pointer; color: var(--color-text);">
                            <option value="1">1 adulto</option>
                            <option value="2" selected>2 adulti</option>
                            <option value="3">3 adulti</option>
                            <option value="4">4 adulti</option>
                            <option value="5">5+ adulti</option>
                        </select>
                    </div>
                </div>
                <div class="col-md-2 text-center text-md-end">
                    <button type="submit" class="btn btn-primary w-100 py-3 rounded-3 fw-semibold transition-all border-0" style="background-color: var(--color-primary); color: var(--color-white);">
                        <?php esc_html_e('Verifica', 'almaretna-child'); ?>
                    </button>
                </div>
            </form>
        </div>
    </section>

    <!-- ══ FEATURES ═════════════════════════════════════════════ -->
    <section class="features py-5" style="background-color: var(--color-bg);">
        <div class="container">
            <div class="row row-cols-2 row-cols-md-5 g-4 py-4 text-center justify-content-center">
                <?php
                $features = [
                    ['icon' => 'pool',      'label' => 'Piscina panoramica', 'desc' => 'Vista mozzafiato sull\'Etna'],
                    ['icon' => 'mountain',  'label' => 'Vista Etna',          'desc' => 'A pochi km dal vulcano'],
                    ['icon' => 'coffee',    'label' => 'Colazione inclusa',   'desc' => 'Prodotti locali artigianali'],
                    ['icon' => 'wifi',      'label' => 'Wi-Fi gratuito',      'desc' => 'Alta velocità ovunque'],
                    ['icon' => 'parking',   'label' => 'Parcheggio privato',  'desc' => 'Gratuito e sorvegliato'],
                ];
                foreach ($features as $f) :
                ?>
                <div class="col d-flex flex-column align-items-center">
                    <div class="feature-item__icon mb-3 d-flex align-items-center justify-content-center rounded-circle" 
                         style="width: 60px; height: 60px; background-color: var(--color-white); color: var(--color-primary); border: 1px solid var(--color-border); box-shadow: 0 2px 8px rgba(197,180,156,0.06);">
                        <?php echo alm_feature_icon($f['icon']); ?>
                    </div>
                    <h3 class="feature-item__label fs-6 fw-semibold mb-1" style="color: var(--color-text);"><?php echo esc_html($f['label']); ?></h3>
                    <p class="feature-item__desc text-muted mb-0" style="font-size: 0.78rem; color: var(--color-text-light);"><?php echo esc_html($f['desc']); ?></p>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>

    <!-- ══ ROOMS ════════════════════════════════════════════════ -->
    <?php if (!empty($rooms)) : ?>
    <section class="home-rooms py-5 bg-white border-top border-bottom border-light">
        <div class="container py-4">
            <div class="d-flex justify-content-between align-items-end mb-5 flex-wrap gap-3">
                <div>
                    <p class="text-uppercase fw-bold mb-2 font-heading text-secondary" style="font-size: 0.75rem; letter-spacing: 0.15em;">
                        <?php esc_html_e('Dove soggiornare', 'almaretna-child'); ?>
                    </p>
                    <h2 class="display-5 fw-bold font-heading mb-0 text-primary" style="color: #4A4136 !important;">
                        <?php esc_html_e('Le nostre camere', 'almaretna-child'); ?>
                    </h2>
                </div>
                <a href="<?php echo esc_url($camere_url); ?>" class="btn btn-link text-decoration-none fw-semibold d-inline-flex align-items-center gap-2 p-0 text-primary" style="transition: transform 0.2s; color: var(--color-primary);">
                    <?php esc_html_e('Tutte le camere', 'almaretna-child'); ?>
                    <svg width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg>
                </a>
            </div>

            <div class="row g-4">
                <?php foreach ($rooms as $room) :
                    $meta         = function_exists('alm_get_room_meta') ? alm_get_room_meta($room->ID) : [];
                    $thumb        = get_the_post_thumbnail_url($room->ID, 'large');
                    $price        = (float) ($meta['base_price'] ?? 0);
                    $adults       = (int) ($meta['capacity_adults'] ?? 2);
                    $children     = (int) ($meta['capacity_children'] ?? 0);
                    $room_url     = get_permalink($room->ID);
                    $room_prenota = add_query_arg(['room' => $room->ID], $prenota_url);
                ?>
                <div class="col-md-4">
                    <article class="card h-100 border-0 rounded-4 overflow-hidden" style="background-color: var(--color-bg); border: 1px solid var(--color-border) !important;">
                        <a href="<?php echo esc_url($room_url); ?>" class="d-block overflow-hidden" style="height: 240px;">
                            <?php if ($thumb) : ?>
                                <img src="<?php echo esc_url($thumb); ?>" alt="<?php echo esc_attr($room->post_title); ?>" class="w-100 h-100 object-fit-cover transition-all hover-scale" />
                            <?php else : ?>
                                <div class="w-100 h-100 d-flex align-items-center justify-content-center text-muted" style="background-color: var(--color-border);">
                                    <svg width="48" height="48" fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24" class="opacity-50"><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21 15 16 10 5 21"/></svg>
                                </div>
                            <?php endif; ?>
                        </a>
                        <div class="card-body p-4 d-flex flex-column">
                            <div class="d-flex align-items-center gap-2 text-muted mb-2" style="font-size: 0.8rem;">
                                <svg width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2"/><circle cx="9" cy="7" r="4"/></svg>
                                <span><?php echo esc_html($adults . ($children ? '+' . $children : '') . ' ospiti'); ?></span>
                            </div>
                            <h3 class="fs-4 fw-bold font-heading mb-3">
                                <a href="<?php echo esc_url($room_url); ?>" class="text-decoration-none hover-text-secondary" style="color: #4A4136;"><?php echo esc_html($room->post_title); ?></a>
                            </h3>
                            <p class="text-muted small mb-4 flex-grow-1" style="line-height: 1.6; color: var(--color-text-light);">
                                <?php echo esc_html(wp_trim_words(get_the_excerpt($room->ID), 22, '…')); ?>
                            </p>
                            <div class="d-flex align-items-center justify-content-between pt-3 border-top border-light">
                                <?php if ($price > 0) : ?>
                                <div>
                                    <span class="fs-4 fw-bold" style="color: var(--color-primary);">€<?php echo esc_html(number_format($price, 0, ',', '.')); ?></span>
                                    <span class="text-muted small">/notte</span>
                                </div>
                                <?php endif; ?>
                                <a href="<?php echo esc_url($room_prenota); ?>" class="btn btn-outline-primary px-3 py-2 rounded-3 fw-semibold border-1" style="color: var(--color-primary); border-color: var(--color-primary);">
                                    <?php esc_html_e('Prenota', 'almaretna-child'); ?>
                                </a>
                            </div>
                        </div>
                    </article>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>
    <?php endif; ?>

    <!-- ══ VILLA SECTION ════════════════════════════════════════ -->
    <section class="villa-section py-5" style="background-color: var(--color-bg); border-bottom: 1px solid var(--color-border);">
        <div class="container py-4">
            <div class="row g-5 align-items-center">
                <div class="col-lg-6">
                    <div class="position-relative">
                        <?php if ($villa_img) : ?>
                            <img src="<?php echo esc_url($villa_img); ?>" alt="Almaretna Villa" class="w-100 rounded-4 object-fit-cover" style="height: 480px; border: 1px solid var(--color-border);" />
                        <?php endif; ?>
                        <div class="position-absolute bottom-0 start-0 m-4 bg-white text-dark px-4 py-3 rounded-4 shadow-sm d-flex align-items-center gap-2" style="background-color: rgba(255,255,255,0.95); backdrop-filter: blur(8px); border: 1px solid var(--color-border);">
                            <svg width="20" height="20" fill="none" stroke="var(--color-primary)" stroke-width="2" viewBox="0 0 24 24"><path d="M3 9l9-7 9 7v11a2 2 0 01-2 2H5a2 2 0 01-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>
                            <span class="fw-semibold" style="font-size: 0.9rem; color: var(--color-text);"><?php esc_html_e('Villa esclusiva', 'almaretna-child'); ?></span>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6">
                    <p class="text-uppercase fw-bold font-heading mb-2 text-secondary" style="font-size: 0.75rem; letter-spacing: 0.15em;">
                        <?php echo esc_html($villa_eyebrow); ?>
                    </p>
                    <h2 class="display-4 fw-bold font-heading mb-4" style="line-height: 1.2; color: #4A4136;">
                        <?php echo esc_html($villa_title); ?>
                    </h2>
                    <div class="divider mb-4 bg-secondary" style="background-color: var(--color-primary) !important;"></div>
                    <p class="fs-6 text-muted mb-3" style="line-height: 1.7; color: var(--color-text) !important;">
                        <?php echo esc_html($villa_text_1); ?>
                    </p>
                    <p class="fs-6 text-muted mb-5" style="line-height: 1.7; color: var(--color-text) !important;">
                        <?php echo esc_html($villa_text_2); ?>
                    </p>
                    <ul class="list-unstyled d-flex flex-column gap-3 mb-5" style="color: var(--color-text);">
                        <li class="d-flex align-items-center gap-3">
                            <span class="d-flex align-items-center justify-content-center rounded-circle" style="width: 24px; height: 24px; background-color: rgba(197, 180, 156, 0.12); color: var(--color-primary);"><svg width="14" height="14" fill="none" stroke="currentColor" stroke-width="3" viewBox="0 0 24 24"><polyline points="20 6 9 17 4 12"/></svg></span>
                            <span class="fw-medium"><?php esc_html_e('Piscina con vista sul vulcano', 'almaretna-child'); ?></span>
                        </li>
                        <li class="d-flex align-items-center gap-3">
                            <span class="d-flex align-items-center justify-content-center rounded-circle" style="width: 24px; height: 24px; background-color: rgba(197, 180, 156, 0.12); color: var(--color-primary);"><svg width="14" height="14" fill="none" stroke="currentColor" stroke-width="3" viewBox="0 0 24 24"><polyline points="20 6 9 17 4 12"/></svg></span>
                            <span class="fw-medium"><?php esc_html_e('Colazione con prodotti biologici locali', 'almaretna-child'); ?></span>
                        </li>
                        <li class="d-flex align-items-center gap-3">
                            <span class="d-flex align-items-center justify-content-center rounded-circle" style="width: 24px; height: 24px; background-color: rgba(197, 180, 156, 0.12); color: var(--color-primary);"><svg width="14" height="14" fill="none" stroke="currentColor" stroke-width="3" viewBox="0 0 24 24"><polyline points="20 6 9 17 4 12"/></svg></span>
                            <span class="fw-medium"><?php esc_html_e('A 10 minuti dal mare di Fondachello', 'almaretna-child'); ?></span>
                        </li>
                        <li class="d-flex align-items-center gap-3">
                            <span class="d-flex align-items-center justify-content-center rounded-circle" style="width: 24px; height: 24px; background-color: rgba(197, 180, 156, 0.12); color: var(--color-primary);"><svg width="14" height="14" fill="none" stroke="currentColor" stroke-width="3" viewBox="0 0 24 24"><polyline points="20 6 9 17 4 12"/></svg></span>
                            <span class="fw-medium"><?php esc_html_e('Check-in flessibile e assistenza h24', 'almaretna-child'); ?></span>
                        </li>
                    </ul>
                    <a href="<?php echo esc_url($camere_url); ?>" class="btn btn-primary px-4 py-3 rounded-3 fw-semibold border-0" style="background-color: var(--color-primary); color: var(--color-white);">
                        <?php esc_html_e('Scopri le camere', 'almaretna-child'); ?>
                        <svg width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24" class="ms-2"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg>
                    </a>
                </div>
            </div>
        </div>
    </section>

    <!-- ══ CTA BANNER ═══════════════════════════════════════════ -->
    <section class="cta-banner py-5 bg-white">
        <div class="container py-4">
            <div class="p-5 rounded-4 border d-flex flex-column flex-lg-row align-items-center justify-content-between gap-4" style="background-color: var(--color-bg); border-color: var(--color-border) !important;">
                <div>
                    <h2 class="fs-2 fw-bold font-heading mb-2 text-primary" style="color: #4A4136 !important;"><?php esc_html_e('Prenota direttamente e risparmia', 'almaretna-child'); ?></h2>
                    <p class="text-muted mb-0" style="color: var(--color-text-light) !important;"><?php esc_html_e('Miglior prezzo garantito — nessuna commissione — cancellazione flessibile', 'almaretna-child'); ?></p>
                </div>
                <div class="d-flex align-items-center gap-3 flex-wrap">
                    <a href="<?php echo esc_url($prenota_url); ?>" class="btn btn-primary px-4 py-3 rounded-3 fw-semibold border-0" style="background-color: var(--color-primary); color: var(--color-white);">
                        <?php esc_html_e('Prenota ora', 'almaretna-child'); ?>
                    </a>
                    <?php
                    $settings    = get_option('alm_booking_settings', []);
                    $host_phone  = sanitize_text_field($settings['host_phone'] ?? '');
                    if ($host_phone) :
                    ?>
                    <a href="tel:<?php echo esc_attr($host_phone); ?>" class="btn btn-outline-secondary px-4 py-3 rounded-3 fw-semibold d-inline-flex align-items-center gap-2" style="border: 1px solid var(--color-secondary); color: var(--color-text);">
                        <svg width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M22 16.92v3a2 2 0 01-2.18 2 19.79 19.79 0 01-8.63-3.07A19.5 19.5 0 013.07 9.8a19.79 19.79 0 01-3.07-8.67A2 2 0 012 0h3a2 2 0 012 1.72 12.84 12.84 0 00.7 2.81 2 2 0 01-.45 2.11L6.09 7.91a16 16 0 006 6l1.27-1.27a2 2 0 012.11-.45 12.84 12.84 0 002.81.7A2 2 0 0122 14.92z"/></svg>
                        <?php echo esc_html($host_phone); ?>
                    </a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </section>

    <!-- ══ LOCATION ═════════════════════════════════════════════ -->
    <section class="location-section py-5 bg-white border-top border-light">
        <div class="container py-4">
            <div class="row g-5">
                <div class="col-lg-5">
                    <p class="text-uppercase fw-bold font-heading mb-2 text-secondary" style="font-size: 0.75rem; letter-spacing: 0.15em;">
                        <?php esc_html_e('Come raggiungerci', 'almaretna-child'); ?>
                    </p>
                    <h2 class="display-5 fw-bold font-heading mb-4 text-primary" style="color: #4A4136 !important;">
                        <?php esc_html_e('Nel cuore della Sicilia', 'almaretna-child'); ?>
                    </h2>
                    <div class="divider mb-4 bg-secondary" style="background-color: var(--color-primary) !important;"></div>
                    <address class="fs-6 text-muted mb-5 lh-lg" style="color: var(--color-text) !important;">
                        <strong>Almaretna</strong><br>
                        Via Scorciavacca Montarsi, 48<br>
                        Nunziata di Mascali (CT) — 95016
                    </address>
                    <ul class="list-unstyled d-flex flex-column gap-3 mb-5 text-muted">
                        <li class="d-flex align-items-center gap-2">
                            <svg width="18" height="18" fill="none" stroke="var(--color-primary)" stroke-width="2" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
                            <span>30 min dall&rsquo;aeroporto di Catania</span>
                        </li>
                        <li class="d-flex align-items-center gap-2">
                            <svg width="18" height="18" fill="none" stroke="var(--color-primary)" stroke-width="2" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
                            <span>10 min dal mare di Fondachello</span>
                        </li>
                        <li class="d-flex align-items-center gap-2">
                            <svg width="18" height="18" fill="none" stroke="var(--color-primary)" stroke-width="2" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
                            <span>15 min da Taormina</span>
                        </li>
                    </ul>
                    <a href="https://maps.google.com/?q=Via+Scorciavacca+Montarsi+48+Nunziata+di+Mascali"
                       target="_blank" rel="noopener noreferrer" class="btn btn-outline-primary px-4 py-3 rounded-3 fw-semibold border-1" style="color: var(--color-primary); border-color: var(--color-primary);">
                        <svg width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24" class="me-2"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0118 0z"/><circle cx="12" cy="10" r="3"/></svg>
                        <?php esc_html_e('Apri su Google Maps', 'almaretna-child'); ?>
                    </a>
                </div>
                <div class="col-lg-7">
                    <div class="rounded-4 overflow-hidden h-100" style="min-height: 380px; border: 1px solid var(--color-border);">
                        <iframe
                            title="Posizione Almaretna"
                            src="https://maps.google.com/maps?q=Via+Scorciavacca+Montarsi+48+Nunziata+di+Mascali&output=embed&z=14"
                            width="100%"
                            height="100%"
                            style="border:0; min-height: 380px;"
                            allowfullscreen=""
                            loading="lazy"
                            referrerpolicy="no-referrer-when-downgrade">
                        </iframe>
                    </div>
                </div>
            </div>
        </div>
    </section>

</main>

<style>
.hover-scale {
    transition: transform 0.4s ease;
}
.hover-scale:hover {
    transform: scale(1.05);
}
.hover-text-secondary:hover {
    color: var(--color-secondary) !important;
}
@keyframes bounceY {
    0%, 100% { transform: translateY(0); }
    50% { transform: translateY(6px); }
}
.bounce-y {
    animation: bounceY 2s infinite ease-in-out;
}
</style>

<?php
get_footer();

// ── Helper: icone features ─────────────────────────────────────────────
function alm_feature_icon(string $key): string {
    $icons = [
        'pool' => '<svg width="24" height="24" fill="none" stroke="currentColor" stroke-width="1.8" viewBox="0 0 24 24"><path d="M2 12h20M2 17c1.5 0 3-1 3-2s1.5-2 3-2 3 1 3 2 1.5 2 3 2 3-1 3-2"/><circle cx="7" cy="7" r="2"/><path d="M7 9v3"/></svg>',
        'mountain' => '<svg width="24" height="24" fill="none" stroke="currentColor" stroke-width="1.8" viewBox="0 0 24 24"><polygon points="3 20 12 4 21 20"/><polyline points="3 20 8 13 12 16 16 11 21 20"/></svg>',
        'coffee' => '<svg width="24" height="24" fill="none" stroke="currentColor" stroke-width="1.8" viewBox="0 0 24 24"><path d="M17 8h1a4 4 0 010 8h-1"/><path d="M3 8h14v9a4 4 0 01-4 4H7a4 4 0 01-4-4z"/><line x1="6" y1="2" x2="6" y2="4"/><line x1="10" y1="2" x2="10" y2="4"/><line x1="14" y1="2" x2="14" y2="4"/></svg>',
        'wifi' => '<svg width="24" height="24" fill="none" stroke="currentColor" stroke-width="1.8" viewBox="0 0 24 24"><path d="M5 12.55a11 11 0 0114.08 0"/><path d="M1.42 9a16 16 0 0121.16 0"/><path d="M8.53 16.11a6 6 0 016.95 0"/><line x1="12" y1="20" x2="12.01" y2="20"/></svg>',
        'parking' => '<svg width="24" height="24" fill="none" stroke="currentColor" stroke-width="1.8" viewBox="0 0 24 24"><rect x="3" y="3" width="18" height="18" rx="2"/><path d="M9 17V7h4a3 3 0 010 6H9"/></svg>',
    ];
    return $icons[$key] ?? '';
}
?>
