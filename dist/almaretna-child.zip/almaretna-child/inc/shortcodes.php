<?php
declare(strict_types=1);

/**
 * Almaretna Child — Shortcodes
 *
 * [alm_booking_form]
 * [alm_rooms_grid columns="3" floor="" type=""]
 * [alm_availability_calendar room_id=""]
 * [alm_room_price room_id=""]
 *
 * @package AlmaretnaChild
 */

defined('ABSPATH') || exit;

// ─── [alm_booking_form] ───────────────────────────────────────────────────────

add_shortcode('alm_booking_form', function (array $atts = []): string {
    // Delegato al plugin almaretna-booking se attivo
    $plugin_view = WP_PLUGIN_DIR . '/almaretna-booking/public/views/booking-form.php';

    if (file_exists($plugin_view)) {
        ob_start();
        include $plugin_view;
        return (string) ob_get_clean();
    }

    // Fallback: il plugin non è ancora attivo
    return '<div class="alert alert-info">' .
        esc_html__('Il modulo di prenotazione è in fase di configurazione. Torna presto!', 'almaretna-child') .
        '</div>';
});

// ─── [alm_rooms_grid] ────────────────────────────────────────────────────────

add_shortcode('alm_rooms_grid', function (array|string $atts = []): string {
    $atts = shortcode_atts([
        'columns' => '3',
        'floor'   => '',
        'type'    => '',
        'adults'  => '',
    ], is_array($atts) ? $atts : [], 'alm_rooms_grid');

    $columns = max(1, min(3, (int) $atts['columns']));

    $query_args = [];
    if (!empty($atts['floor'])) {
        $query_args['room_floor'] = sanitize_text_field($atts['floor']);
    }
    if (!empty($atts['type'])) {
        $query_args['room_type'] = sanitize_text_field($atts['type']);
    }
    if (!empty($atts['adults'])) {
        $query_args['adults'] = absint($atts['adults']);
    }

    $rooms_query = alm_rooms_query($query_args);

    if (!$rooms_query->have_posts()) {
        return '<p class="text-center text-light">' .
            esc_html__('Nessuna camera disponibile con i filtri selezionati.', 'almaretna-child') .
            '</p>';
    }

    $grid_class = 'rooms-grid';
    if ($columns === 2) {
        $grid_class .= ' rooms-grid--2col';
    } elseif ($columns === 1) {
        $grid_class .= ' rooms-grid--1col';
    }

    ob_start();
    ?>
    <div class="<?php echo esc_attr($grid_class); ?>">
        <?php while ($rooms_query->have_posts()) : $rooms_query->the_post(); ?>
            <?php
            $post_id      = get_the_ID();
            $meta         = alm_get_room_meta($post_id);
            $thumb_url    = alm_get_room_thumbnail_url($post_id, 'large');
            $amenities    = alm_get_room_amenities($post_id);
            $room_type    = alm_get_room_type($post_id);
            $room_floor   = alm_get_room_floor($post_id);
            $sharing_note = alm_get_bathroom_sharing_note($post_id);
            ?>
            <article class="room-card">
                <div class="room-card__image-wrap">
                    <?php if ($thumb_url) : ?>
                        <img
                            src="<?php echo esc_url($thumb_url); ?>"
                            alt="<?php echo esc_attr(get_the_title()); ?>"
                            loading="lazy"
                            width="600"
                            height="450"
                        />
                    <?php else : ?>
                        <div class="room-card__img-placeholder">
                            <span class="dashicons dashicons-building"></span>
                            <span><?php echo esc_html(get_the_title()); ?></span>
                        </div>
                    <?php endif; ?>
                    <div class="room-card__badge">
                        <?php if ($room_floor) : ?>
                            <span class="badge badge-primary">
                                <?php echo esc_html(alm_get_floor_label($room_floor->slug)); ?>
                            </span>
                        <?php endif; ?>
                        <?php if ($room_type) : ?>
                            <span class="badge badge-light">
                                <?php echo esc_html($room_type->name); ?>
                            </span>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="room-card__body">
                    <h3 class="room-card__title">
                        <a href="<?php the_permalink(); ?>">
                            <?php the_title(); ?>
                        </a>
                    </h3>

                    <p class="room-card__excerpt">
                        <?php echo esc_html(get_the_excerpt()); ?>
                    </p>

                    <?php if (!empty($amenities)) : ?>
                        <div class="room-card__amenities">
                            <?php foreach (array_slice($amenities, 0, 5) as $amenity) : ?>
                                <span class="room-card__amenity">
                                    <span class="dashicons <?php echo esc_attr(alm_get_amenity_icon($amenity->slug)); ?>"></span>
                                    <?php echo esc_html($amenity->name); ?>
                                </span>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>

                    <?php if ($sharing_note) : ?>
                        <p class="room-card__sharing-note">
                            <span class="dashicons dashicons-info"></span>
                            <?php echo esc_html($sharing_note); ?>
                        </p>
                    <?php endif; ?>
                </div>

                <div class="room-card__footer">
                    <div class="room-card__price">
                        <span class="room-card__price-amount">
                            <?php echo wp_kses_post(alm_format_price($meta['base_price'])); ?>
                        </span>
                        <span class="room-card__price-label">
                            <?php esc_html_e('/ notte', 'almaretna-child'); ?>
                            <?php if ($meta['min_stay'] > 1) : ?>
                                &middot; min. <?php echo esc_html((string) $meta['min_stay']); ?> notti
                            <?php endif; ?>
                        </span>
                    </div>
                    <a href="<?php the_permalink(); ?>" class="btn btn-primary btn-sm room-card__cta">
                        <?php esc_html_e('Scopri', 'almaretna-child'); ?>
                    </a>
                </div>
            </article>
        <?php endwhile; ?>
    </div>
    <?php
    wp_reset_postdata();
    return (string) ob_get_clean();
});

// ─── [alm_availability_calendar] ─────────────────────────────────────────────

add_shortcode('alm_availability_calendar', function (array|string $atts = []): string {
    $atts = shortcode_atts([
        'room_id' => '',
    ], is_array($atts) ? $atts : [], 'alm_availability_calendar');

    $room_id = absint($atts['room_id']);
    if (!$room_id) {
        return '';
    }

    // Se il plugin è attivo, delega
    $plugin_view = WP_PLUGIN_DIR . '/almaretna-booking/public/views/calendar.php';
    if (file_exists($plugin_view)) {
        ob_start();
        include $plugin_view;
        return (string) ob_get_clean();
    }

    // Fallback: calendario statico placeholder
    $meta = alm_get_room_meta($room_id);
    ob_start();
    ?>
    <div
        class="availability-calendar"
        data-room-id="<?php echo esc_attr((string) $room_id); ?>"
        data-room-slug="<?php echo esc_attr($meta['room_id']); ?>"
    >
        <div class="availability-calendar__header">
            <button class="availability-calendar__nav" data-dir="prev" aria-label="Mese precedente">&lsaquo;</button>
            <span class="availability-calendar__month-title">Disponibilità</span>
            <button class="availability-calendar__nav" data-dir="next" aria-label="Mese successivo">&rsaquo;</button>
        </div>
        <p style="padding:var(--space-lg);text-align:center;color:var(--color-text-light);">
            <?php esc_html_e('Calendario disponibilità in caricamento…', 'almaretna-child'); ?>
        </p>
    </div>
    <?php
    return (string) ob_get_clean();
});

// ─── [alm_room_price] ────────────────────────────────────────────────────────

add_shortcode('alm_room_price', function (array|string $atts = []): string {
    $atts = shortcode_atts([
        'room_id' => '',
    ], is_array($atts) ? $atts : [], 'alm_room_price');

    $room_id = absint($atts['room_id']);
    if (!$room_id) {
        return '';
    }

    $meta     = alm_get_room_meta($room_id);
    $prenota_page = get_pages(['meta_key' => '_wp_page_template', 'meta_value' => 'templates/template-booking.php', 'number' => 1]);
    $book_url  = !empty($prenota_page) ? get_permalink($prenota_page[0]->ID) : home_url('/prenota/');

    ob_start();
    ?>
    <div
        class="room-price-box"
        data-room-id="<?php echo esc_attr((string) $room_id); ?>"
    >
        <div class="room-price-box__capacita">
            <span class="dashicons dashicons-admin-users"></span>
            <?php
            printf(
                esc_html__('Fino a %d adulti', 'almaretna-child'),
                $meta['capacity_adults']
            );
            if ($meta['capacity_children'] > 0) {
                echo ' + ' . esc_html((string) $meta['capacity_children']) . ' ' .
                    esc_html__('bambini', 'almaretna-child');
            }
            ?>
        </div>

        <div class="room-price-box__price">
            <span class="room-price-box__amount" data-js="price-amount">
                <?php echo wp_kses_post(alm_format_price($meta['base_price'])); ?>
            </span>
            <span class="room-price-box__per-night">
                <?php esc_html_e('/ notte', 'almaretna-child'); ?>
            </span>
        </div>

        <?php if ($meta['min_stay'] > 1) : ?>
            <p style="font-size:var(--fs-xs);color:var(--color-text-light);margin-bottom:var(--space-md);">
                <?php
                printf(
                    esc_html__('Soggiorno minimo: %d notti', 'almaretna-child'),
                    $meta['min_stay']
                );
                ?>
            </p>
        <?php endif; ?>

        <div class="room-price-box__form">
            <div class="form-group">
                <label for="rpb-checkin-<?php echo esc_attr((string) $room_id); ?>">
                    <?php esc_html_e('Check-in', 'almaretna-child'); ?>
                </label>
                <input
                    type="text"
                    id="rpb-checkin-<?php echo esc_attr((string) $room_id); ?>"
                    class="form-control alm-datepicker-checkin"
                    data-room-id="<?php echo esc_attr((string) $room_id); ?>"
                    placeholder="<?php esc_attr_e('gg/mm/aaaa', 'almaretna-child'); ?>"
                    readonly
                />
            </div>
            <div class="form-group">
                <label for="rpb-checkout-<?php echo esc_attr((string) $room_id); ?>">
                    <?php esc_html_e('Check-out', 'almaretna-child'); ?>
                </label>
                <input
                    type="text"
                    id="rpb-checkout-<?php echo esc_attr((string) $room_id); ?>"
                    class="form-control alm-datepicker-checkout"
                    data-room-id="<?php echo esc_attr((string) $room_id); ?>"
                    placeholder="<?php esc_attr_e('gg/mm/aaaa', 'almaretna-child'); ?>"
                    readonly
                />
            </div>
            <a
                href="<?php echo esc_url($book_url ?: home_url('/prenota/')); ?>"
                class="btn btn-primary btn-lg"
            >
                <?php esc_html_e('Prenota ora', 'almaretna-child'); ?>
            </a>
        </div>

        <p class="room-price-box__info">
            <span class="dashicons dashicons-lock" style="font-size:14px;vertical-align:middle;"></span>
            <?php esc_html_e('Pagamento sicuro. Cancellazione gratuita.', 'almaretna-child'); ?>
        </p>
    </div>
    <?php
    return (string) ob_get_clean();
});


// ─── [alm_image] ─────────────────────────────────────────────────────────────
//
// Permette di inserire immagini nelle pagine con posizionamento preciso.
//
// Parametri:
//   src        URL immagine (obbligatorio) oppure id=<media_library_id>
//   id         ID media library WordPress (alternativo a src)
//   align      left | right | center | full (default: center)
//   width      es. "50%" oppure "400px" (default: auto)
//   caption    Testo didascalia (opzionale)
//   alt        Testo alternativo (default: caption o nome file)
//   link       URL a cui linkare l'immagine (opzionale)
//   radius     border-radius override es. "0" per disabilitare (default: tema)
//   shadow     yes | no (default: yes)
//   class      Classi CSS aggiuntive
//
// Esempi:
//   [alm_image id="42" align="right" width="40%" caption="Vista Etna"]
//   [alm_image src="https://..." align="left" width="300px"]
//   [alm_image id="55" align="full"]

add_shortcode('alm_image', function (array $atts = [], ?string $content = null): string {
    $atts = shortcode_atts([
        'src'     => '',
        'id'      => '',
        'align'   => 'center',
        'width'   => '',
        'caption' => '',
        'alt'     => '',
        'link'    => '',
        'radius'  => '',
        'shadow'  => 'yes',
        'class'   => '',
    ], $atts, 'alm_image');

    // Risolvi URL immagine
    $src = '';
    $alt = esc_attr($atts['alt']);

    if (!empty($atts['id'])) {
        $img_id = absint($atts['id']);
        $src    = wp_get_attachment_url($img_id);
        if (empty($alt)) {
            $alt = esc_attr(get_post_meta($img_id, '_wp_attachment_image_alt', true) ?: get_the_title($img_id));
        }
        // Se caption non specificata, usa quella della media library
        if (empty($atts['caption'])) {
            $attachment = get_post($img_id);
            $atts['caption'] = $attachment ? wp_strip_all_tags($attachment->post_excerpt) : '';
        }
    } elseif (!empty($atts['src'])) {
        $src = esc_url($atts['src']);
        if (empty($alt)) {
            $alt = esc_attr(basename((string) $atts['src']));
        }
    }

    if (!$src) {
        return '<!-- [alm_image] errore: specificare src="" oppure id="" -->';
    }

    // Classi wrapper
    $align_class = 'alm-image-wrap--' . sanitize_html_class($atts['align']);
    $extra_class = sanitize_html_class((string) $atts['class']);
    $wrap_class  = implode(' ', array_filter(['alm-image-wrap', $align_class, $extra_class]));

    // Stili inline wrapper
    $wrap_style = '';
    if (!empty($atts['width'])) {
        $wrap_style .= 'max-width:' . esc_attr($atts['width']) . ';';
    }

    // Stili inline immagine
    $img_style = '';
    if ($atts['radius'] !== '') {
        $img_style .= 'border-radius:' . esc_attr($atts['radius']) . ';';
    }
    if ($atts['shadow'] === 'no') {
        $img_style .= 'box-shadow:none;';
    }

    // Immagine
    $img_tag = sprintf(
        '<img src="%s" alt="%s" loading="lazy"%s />',
        esc_url($src),
        $alt,
        $img_style ? ' style="' . $img_style . '"' : ''
    );

    // Eventuale link
    if (!empty($atts['link'])) {
        $img_tag = sprintf('<a href="%s" target="_blank" rel="noopener">%s</a>', esc_url($atts['link']), $img_tag);
    }

    // Caption
    $caption_html = '';
    if (!empty($atts['caption'])) {
        $caption_html = '<figcaption class="alm-image-caption">' . esc_html($atts['caption']) . '</figcaption>';
    }

    return sprintf(
        '<figure class="%s"%s>%s%s</figure>',
        esc_attr($wrap_class),
        $wrap_style ? ' style="' . $wrap_style . '"' : '',
        $img_tag,
        $caption_html
    );
});

// ─── [alm_gallery] ───────────────────────────────────────────────────────────
//
// Galleria immagini grid dal media library.
//
// Parametri:
//   ids     ID immagini separati da virgola (obbligatorio)
//   cols    2 | 3 | 4 (default: 3)
//   link    yes | no — clicca apre immagine originale (default: no)
//
// Esempio:
//   [alm_gallery ids="10,11,12,13" cols="3"]

add_shortcode('alm_gallery', function (array $atts = []): string {
    $atts = shortcode_atts([
        'ids'  => '',
        'cols' => '3',
        'link' => 'no',
    ], $atts, 'alm_gallery');

    if (empty($atts['ids'])) {
        return '<!-- [alm_gallery] errore: specificare ids="" -->';
    }

    $ids  = array_filter(array_map('absint', explode(',', $atts['ids'])));
    $cols = in_array($atts['cols'], ['2','3','4'], true) ? $atts['cols'] : '3';

    if (empty($ids)) {
        return '';
    }

    $items = '';
    foreach ($ids as $img_id) {
        $src = wp_get_attachment_url($img_id);
        if (!$src) continue;
        $alt = esc_attr(get_post_meta($img_id, '_wp_attachment_image_alt', true) ?: '');
        $img = sprintf('<img src="%s" alt="%s" loading="lazy" />', esc_url($src), $alt);
        if ($atts['link'] === 'yes') {
            $img = sprintf('<a href="%s" target="_blank" rel="noopener">%s</a>', esc_url($src), $img);
        }
        $items .= '<div class="alm-gallery__item">' . $img . '</div>';
    }

    return sprintf(
        '<div class="alm-gallery alm-gallery--cols-%s">%s</div>',
        esc_attr($cols),
        $items
    );
});
