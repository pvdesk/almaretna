<?php
/**
 * Template singola camera (CPT: almaretna_room)
 * Restructured with Bootstrap 5.3 for a professional, lightweight layout.
 *
 * @package AlmaretnaChild
 */

declare(strict_types=1);

get_header();

while (have_posts()) :
    the_post();

    $post_id      = get_the_ID();
    $meta         = alm_get_room_meta($post_id);
    $amenities    = alm_get_room_amenities($post_id);
    $room_type    = alm_get_room_type($post_id);
    $room_floor   = alm_get_room_floor($post_id);
    $sharing_note = alm_get_bathroom_sharing_note($post_id);
    $thumb_url    = alm_get_room_thumbnail_url($post_id, 'full');

    // Gallery: immagine in evidenza + allegati
    $gallery_ids  = get_post_meta($post_id, '_room_gallery', true);
    $gallery_ids  = !empty($gallery_ids) ? array_filter(explode(',', $gallery_ids)) : [];
    $thumb_id     = get_post_thumbnail_id($post_id);
    if ($thumb_id) {
        array_unshift($gallery_ids, (string) $thumb_id);
    }
    $gallery_ids = array_unique($gallery_ids);
?>

<!-- Hero camera -->
<section class="room-details__hero position-relative d-flex align-items-center"
         style="min-height: 50vh; padding-top: 120px; padding-bottom: 80px; background-color: var(--color-primary); <?php echo $thumb_url ? 'background-image:url(' . esc_url($thumb_url) . '); background-size: cover; background-position: center;' : ''; ?>">
    
    <div class="position-absolute top-0 start-0 end-0 bottom-0" style="background: linear-gradient(180deg, rgba(252, 250, 247, 0.45) 0%, rgba(252, 250, 247, 0.78) 100%); z-index: 1;"></div>
    
    <div class="container position-relative text-center" style="z-index: 2;">
        <div class="room-details__hero-content mx-auto" style="max-width: 900px;">
            <!-- Breadcrumb -->
            <p class="small text-uppercase fw-semibold tracking-wider mb-2" style="font-size: 0.75rem;">
                <a href="<?php echo esc_url(home_url('/')); ?>" class="text-decoration-none" style="color: var(--color-text-light);">Home</a>
                <span style="color: var(--color-text-light);">&rsaquo;</span>
                <?php
                $camere_page = get_pages(['meta_key' => '_wp_page_template', 'meta_value' => 'templates/template-rooms.php', 'number' => 1]);
                $camere_url  = !empty($camere_page) ? get_permalink($camere_page[0]->ID) : home_url('/camere/');
                ?>
                <a href="<?php echo esc_url($camere_url); ?>" class="text-decoration-none" style="color: var(--color-text-light);">
                    <?php esc_html_e('Camere', 'almaretna-child'); ?>
                </a>
                <span style="color: var(--color-text-light);">&rsaquo;</span> <span style="color: var(--color-text);"><?php the_title(); ?></span>
            </p>

            <!-- Badges -->
            <div class="d-flex flex-wrap justify-content-center gap-2 mb-3">
                <?php if ($room_floor) : ?>
                    <span class="badge px-3 py-2 fw-semibold" style="background-color: var(--color-secondary); color: var(--color-white);">
                        <?php echo esc_html(alm_get_floor_label($room_floor->slug)); ?>
                    </span>
                <?php endif; ?>
                <?php if ($room_type) : ?>
                    <span class="badge px-3 py-2 fw-semibold" style="background-color: var(--color-accent); color: var(--color-text); border: 1px solid var(--color-border);">
                        <?php echo esc_html($room_type->name); ?>
                    </span>
                <?php endif; ?>
                <?php if ($meta['bathroom_type'] === 'shared') : ?>
                    <span class="badge px-3 py-2 fw-semibold bg-danger text-white">
                        <?php esc_html_e('Bagno condiviso', 'almaretna-child'); ?>
                    </span>
                <?php endif; ?>
            </div>

            <h1 class="display-5 fw-bold font-heading mb-3" style="color: var(--color-text);"><?php the_title(); ?></h1>

            <p class="fs-5 fw-light mb-0 mx-auto" style="line-height: 1.6; color: var(--color-text-light); max-width: 700px;">
                <?php echo esc_html(get_the_excerpt()); ?>
            </p>
        </div>
    </div>
</section>

<!-- Layout 2 colonne: gallery + dettagli in griglia Bootstrap -->
<main id="main-content" class="py-5" style="background-color: var(--color-bg);">
    <div class="container py-3">
        <div class="row g-5">

            <!-- Colonna sinistra: gallery + contenuto -->
            <div class="col-lg-8">
                
                <!-- Gallery con lightbox CSS-only -->
                <?php if (!empty($gallery_ids)) : ?>
                    <div class="room-gallery mb-5 rounded-4 overflow-hidden bg-white p-3 shadow-sm border border-light">
                        <?php
                        $first_img = wp_get_attachment_image_src($gallery_ids[0], 'large');
                        ?>

                        <!-- Immagine principale -->
                        <div class="room-gallery__main mb-3 overflow-hidden rounded-3" style="max-height: 480px;">
                            <?php if ($first_img) : ?>
                                <img
                                    id="room-gallery-main-img"
                                    src="<?php echo esc_url($first_img[0]); ?>"
                                    alt="<?php echo esc_attr(get_the_title()); ?>"
                                    class="w-100 object-fit-cover"
                                    style="height: 450px;"
                                />
                            <?php endif; ?>
                        </div>

                        <!-- Thumbnails -->
                        <?php if (count($gallery_ids) > 1) : ?>
                            <div class="row g-2 room-gallery__thumbs">
                                <?php foreach ($gallery_ids as $img_id) :
                                    $thumb = wp_get_attachment_image_src($img_id, 'thumbnail');
                                    $full  = wp_get_attachment_image_src($img_id, 'large');
                                    if (!$thumb || !$full) continue;
                                ?>
                                    <div class="col-3 col-sm-2">
                                        <div
                                            class="room-gallery__thumb overflow-hidden rounded-2 ratio ratio-1x1 border border-2 border-transparent <?php echo $img_id === $gallery_ids[0] ? 'border-primary' : ''; ?>"
                                            role="button"
                                            style="cursor: pointer;"
                                            tabindex="0"
                                            data-full="<?php echo esc_url($full[0]); ?>"
                                            aria-label="<?php esc_attr_e('Vedi immagine', 'almaretna-child'); ?>"
                                        >
                                            <img
                                                src="<?php echo esc_url($thumb[0]); ?>"
                                                alt=""
                                                class="w-100 h-100 object-fit-cover"
                                            />
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        <?php endif; ?>
                    </div>

                    <script>
                    (function () {
                        var mainImg = document.getElementById('room-gallery-main-img');
                        var thumbs  = document.querySelectorAll('.room-gallery__thumb');
                        thumbs.forEach(function (thumb) {
                            thumb.addEventListener('click', function () {
                                thumbs.forEach(function (t) { t.classList.remove('border-primary'); });
                                thumb.classList.add('border-primary');
                                if (mainImg) mainImg.src = thumb.dataset.full;
                            });
                            thumb.addEventListener('keydown', function (e) {
                                if (e.key === 'Enter' || e.key === ' ') { thumb.click(); }
                            });
                        });
                    })();
                    </script>
                <?php endif; ?>

                <!-- Descrizione completa -->
                <?php if (get_the_content()) : ?>
                    <div class="room-details__content bg-white p-4 p-md-5 rounded-4 shadow-sm border border-light mb-4" style="line-height: 1.8;">
                        <h2 class="font-heading fw-bold text-primary mb-4 pb-2 border-bottom border-light">
                            <?php esc_html_e('La camera', 'almaretna-child'); ?>
                        </h2>
                        <?php the_content(); ?>
                    </div>
                <?php endif; ?>

                <!-- Dotazioni -->
                <?php if (!empty($amenities)) : ?>
                    <div class="bg-white p-4 p-md-5 rounded-4 shadow-sm border border-light mb-4">
                        <h2 class="font-heading fw-bold text-primary mb-4 pb-2 border-bottom border-light">
                            <?php esc_html_e('Dotazioni', 'almaretna-child'); ?>
                        </h2>
                        <div class="row row-cols-2 row-cols-md-3 g-3">
                            <?php foreach ($amenities as $amenity) : ?>
                                <div class="col d-flex align-items-center gap-2 py-2">
                                    <span class="dashicons <?php echo esc_attr(alm_get_amenity_icon($amenity->slug)); ?>" style="color: var(--color-secondary); font-size: 20px; width: 20px; height: 20px;"></span>
                                    <span class="fw-medium text-muted small">
                                        <?php echo esc_html($amenity->name); ?>
                                    </span>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                <?php endif; ?>

                <!-- Nota bagno condiviso -->
                <?php if ($sharing_note) : ?>
                    <div class="alert alert-warning p-4 rounded-4 shadow-sm border-0 mb-4 d-flex align-items-center gap-3" style="background-color: #FAF3E0; color: #8A6D3B;">
                        <span class="dashicons dashicons-info" style="font-size: 24px; width: 24px; height: 24px; color: #8A6D3B;"></span>
                        <span class="fw-medium small"><?php echo esc_html($sharing_note); ?></span>
                    </div>
                <?php endif; ?>

                <!-- Dettagli soggiorno -->
                <div class="bg-white p-4 p-md-5 rounded-4 shadow-sm border border-light mb-4">
                    <h2 class="font-heading fw-bold text-primary mb-4 pb-2 border-bottom border-light">
                        <?php esc_html_e('Dettagli soggiorno', 'almaretna-child'); ?>
                    </h2>
                    <div class="row row-cols-1 row-cols-sm-2 g-3">
                        <div class="col d-flex align-items-center gap-2 py-1">
                            <span class="dashicons dashicons-admin-users text-secondary"></span>
                            <span class="text-muted small">
                                <?php
                                printf(
                                    esc_html(_n('Max %d adulto', 'Max %d adulti', $meta['capacity_adults'], 'almaretna-child')),
                                    $meta['capacity_adults']
                                );
                                if ($meta['capacity_children'] > 0) {
                                    echo ' + ';
                                    printf(
                                        esc_html(_n('%d bambino', '%d bambini', $meta['capacity_children'], 'almaretna-child')),
                                        $meta['capacity_children']
                                    );
                                }
                                ?>
                            </span>
                        </div>
                        <div class="col d-flex align-items-center gap-2 py-1">
                            <span class="dashicons dashicons-calendar-alt text-secondary"></span>
                            <span class="text-muted small">
                                <?php
                                if ($meta['min_stay'] > 1) {
                                    printf(
                                        esc_html(__('Minimo %d notti di soggiorno', 'almaretna-child')),
                                        $meta['min_stay']
                                    );
                                } else {
                                    esc_html_e('1 notte minimo di soggiorno', 'almaretna-child');
                                }
                                ?>
                            </span>
                        </div>
                        <div class="col d-flex align-items-center gap-2 py-1">
                            <span class="dashicons dashicons-clock text-secondary"></span>
                            <span class="text-muted small">
                                <?php esc_html_e('Check-in: ore 15:00', 'almaretna-child'); ?>
                            </span>
                        </div>
                        <div class="col d-flex align-items-center gap-2 py-1">
                            <span class="dashicons dashicons-clock text-secondary"></span>
                            <span class="text-muted small">
                                <?php esc_html_e('Check-out: ore 11:00', 'almaretna-child'); ?>
                            </span>
                        </div>
                    </div>
                </div>

                <!-- Calendario disponibilità -->
                <div class="bg-white p-4 p-md-5 rounded-4 shadow-sm border border-light mb-4">
                    <h2 class="font-heading fw-bold text-primary mb-4 pb-2 border-bottom border-light">
                        <?php esc_html_e('Disponibilità camera', 'almaretna-child'); ?>
                    </h2>
                    <?php echo do_shortcode('[alm_availability_calendar room_id="' . esc_attr((string) $post_id) . '"]'); ?>
                </div>

            </div>

            <!-- Colonna destra: box prezzo sticky sidebar -->
            <div class="col-lg-4">
                <aside class="position-sticky" style="top: 130px;">
                    <?php echo do_shortcode('[alm_room_price room_id="' . esc_attr((string) $post_id) . '"]'); ?>
                </aside>
            </div>

        </div>
    </div>
</main>

<!-- Sezione "Potrebbe interessarti" -->
<?php
$related_args = [
    'post_type'      => 'almaretna_room',
    'post_status'    => 'publish',
    'posts_per_page' => 3,
    'post__not_in'   => [$post_id],
    'orderby'        => 'rand',
];

// Prova prima stessa tipologia
if ($room_type) {
    $related_args['tax_query'] = [[
        'taxonomy' => 'room_type',
        'field'    => 'slug',
        'terms'    => $room_type->slug,
    ]];
}

$related_query = new WP_Query($related_args);

// Fallback: se non ci sono abbastanza camere, rimuovi filtro tipologia
if (!$related_query->have_posts() || $related_query->post_count < 1) {
    unset($related_args['tax_query']);
    $related_query = new WP_Query($related_args);
}

if ($related_query->have_posts()) : ?>
    <section class="related-rooms py-5 bg-white border-top border-light">
        <div class="container py-4">
            <h2 class="display-5 fw-bold font-heading text-primary text-center mb-5">
                <?php esc_html_e('Camere correlate', 'almaretna-child'); ?>
            </h2>
            <div class="row g-4">
                <?php while ($related_query->have_posts()) : $related_query->the_post(); ?>
                    <?php
                    $rel_id       = get_the_ID();
                    $rel_meta     = alm_get_room_meta($rel_id);
                    $rel_thumb    = alm_get_room_thumbnail_url($rel_id, 'large');
                    $rel_floor    = alm_get_room_floor($rel_id);
                    $rel_type     = alm_get_room_type($rel_id);
                    ?>
                    <div class="col-md-4">
                        <article class="card h-100 border-0 rounded-4 shadow-sm overflow-hidden" style="background-color: var(--color-bg);">
                            <div class="position-relative overflow-hidden" style="height: 200px;">
                                <?php if ($rel_thumb) : ?>
                                    <img
                                        src="<?php echo esc_url($rel_thumb); ?>"
                                        alt="<?php echo esc_attr(get_the_title()); ?>"
                                        loading="lazy"
                                        class="w-100 h-100 object-fit-cover transition-all hover-scale"
                                    />
                                <?php endif; ?>
                                <div class="position-absolute top-0 start-0 m-3">
                                    <?php if ($rel_floor) : ?>
                                        <span class="badge px-3 py-2 fw-semibold" style="background-color: var(--color-secondary); color: var(--color-white);">
                                            <?php echo esc_html(alm_get_floor_label($rel_floor->slug)); ?>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="card-body p-4 d-flex flex-column">
                                <h3 class="fs-5 fw-bold font-heading mb-3 text-primary">
                                    <a href="<?php the_permalink(); ?>" class="text-decoration-none text-primary hover-text-secondary"><?php the_title(); ?></a>
                                </h3>
                                <p class="text-muted small mb-4 flex-grow-1" style="line-height: 1.6;"><?php echo esc_html(get_the_excerpt()); ?></p>
                                <div class="d-flex align-items-center justify-content-between pt-3 border-top border-light">
                                    <div class="room-card__price">
                                        <span class="fs-5 fw-bold text-primary">
                                            <?php echo wp_kses_post(alm_format_price($rel_meta['base_price'])); ?>
                                        </span>
                                        <span class="text-muted small">/ notte</span>
                                    </div>
                                    <a href="<?php the_permalink(); ?>" class="btn btn-outline-primary px-3 py-2 rounded-3 fw-semibold border-1" style="color: var(--color-primary); border-color: var(--color-primary); font-size: 0.85rem;">
                                        <?php esc_html_e('Scopri', 'almaretna-child'); ?>
                                    </a>
                                </div>
                            </div>
                        </article>
                    </div>
                <?php endwhile; wp_reset_postdata(); ?>
            </div>
        </div>
    </section>
<?php endif; ?>

<!-- Schema markup JSON-LD HotelRoom -->
<script type="application/ld+json">
<?php
$amenity_features = [];
foreach ($amenities as $am) {
    $amenity_features[] = [
        '@type' => 'LocationFeatureSpecification',
        'name'  => $am->name,
        'value' => true,
    ];
}

$schema = [
    '@context'       => 'https://schema.org',
    '@type'          => 'HotelRoom',
    'name'           => get_the_title(),
    'description'    => get_the_excerpt(),
    'occupancy'      => [
        '@type'    => 'QuantitativeValue',
        'maxValue' => $meta['capacity_adults'] + $meta['capacity_children'],
    ],
    'amenityFeature' => $amenity_features,
    'containedInPlace' => [
        '@type'   => 'LodgingBusiness',
        'name'    => 'Almaretna',
        'address' => [
            '@type'           => 'PostalAddress',
            'streetAddress'   => 'Via Scorciavacca Montarsi, 48',
            'addressLocality' => 'Nunziata di Mascali',
            'addressRegion'   => 'CT',
            'postalCode'      => '95016',
            'addressCountry'  => 'IT',
        ],
    ],
];

if ($thumb_url) {
    $schema['image'] = $thumb_url;
}
if ($meta['base_price'] > 0) {
    $schema['offers'] = [
        '@type'         => 'Offer',
        'price'         => $meta['base_price'],
        'priceCurrency' => 'EUR',
        'url'           => get_permalink(),
    ];
}

echo wp_json_encode($schema, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
?>
</script>

<?php
// Recupera le 4 foto pre-footer
$footer_images = [];
for ($i = 1; $i <= 4; $i++) {
    $img_id = (int) get_post_meta($post_id, "_room_footer_img_{$i}", true);
    if ($img_id > 0) {
        $img_url = wp_get_attachment_image_url($img_id, 'large');
        if ($img_url) {
            $footer_images[] = $img_url;
        }
    }
}

if (!empty($footer_images)) :
?>
<!-- Galleria Dettaglio Pre-Footer -->
<section class="room-details__pre-footer py-5" style="background-color: var(--color-accent); border-top: 1px solid var(--color-border); border-bottom: 1px solid var(--color-border);">
    <div class="container">
        <div class="row g-4 justify-content-center">
            <?php foreach ($footer_images as $img_url) : ?>
                <div class="col-md-3 col-sm-6 col-12">
                    <div class="card border-0 rounded-4 overflow-hidden shadow-sm h-100 position-relative" style="aspect-ratio: 4/3;">
                        <img src="<?php echo esc_url($img_url); ?>" alt="" class="w-100 h-100 object-fit-cover transition-all hover-scale" />
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>
<?php endif; ?>

<?php
endwhile;
get_footer();
?>
